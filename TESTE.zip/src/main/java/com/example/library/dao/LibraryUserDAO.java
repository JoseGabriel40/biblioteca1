package com.example.library.dao;

import com.example.library.model.LibraryUser;
import com.example.library.util.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibraryUserDAO {
    private Connection conn = Database.getConnection();

    public LibraryUserDAO() throws SQLException {}

    // Adiciona novo aluno com verificação de e-mail duplicado
    public void add(LibraryUser u) throws SQLException {
        String sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getName());
            ps.setString(2, u.getCourse());
            ps.setString(3, u.getTurma());
            ps.execute();
        }



    // Se não existir, insere o novo aluno
        sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, u.getName());
            ps.setString(2, u.getCourse());   // curso → email
            ps.setString(3, u.getTurma());    // turma → password
            ps.execute();
        }
    }

    // Lista todos os alunos
    public List<LibraryUser> list() throws SQLException {
        List<LibraryUser> list = new ArrayList<>();
        String sql = "SELECT * FROM users";
        ResultSet rs = conn.createStatement().executeQuery(sql);

        while (rs.next()) {
            LibraryUser u = new LibraryUser();
            u.setId(rs.getInt("id"));
            u.setName(rs.getString("name"));
            u.setCourse(rs.getString("email"));     // curso está em email
            u.setTurma(rs.getString("password"));   // turma está em password
            list.add(u);
        }

        rs.close();
        return list;
    }

    // Busca aluno por ID
    public LibraryUser getById(int id) throws SQLException {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            LibraryUser u = null;
            if (rs.next()) {
                u = new LibraryUser();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setCourse(rs.getString("email"));
                u.setTurma(rs.getString("password"));
            }

            rs.close();
            return u;
        }
    }

    // Busca aluno por curso e turma (login)
    public LibraryUser getByCourseAndClass(String course, String turma) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, course);
            ps.setString(2, turma);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                LibraryUser user = new LibraryUser();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setCourse(rs.getString("email"));
                user.setTurma(rs.getString("password"));
                rs.close();
                return user;
            }

            rs.close();
            return null;
        }
    }
}
