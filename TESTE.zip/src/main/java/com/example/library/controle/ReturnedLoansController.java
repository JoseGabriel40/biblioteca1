package com.example.library.controle;

import com.example.library.dao.LoanDAO;
import com.example.library.model.Loan;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.time.LocalDate;

public class ReturnedLoansController {

    @FXML
    private TableView<Loan> loanTable;
    @FXML private TableColumn<Loan, Integer> loanIdColumn;
    @FXML private TableColumn<Loan, String> userColumn;
    @FXML private TableColumn<Loan, String> bookColumn;
    @FXML private TableColumn<Loan, LocalDate> loanDateColumn;
    @FXML private TableColumn<Loan, LocalDate> returnDateColumn;

    private final LoanDAO loanDAO = new LoanDAO();

    @FXML
    public void initialize() {
        loanIdColumn.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getId()).asObject());
        userColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getUser().getName()));
        bookColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getBook().getTitle()));
        loanDateColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getLoanDate()));
        returnDateColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getReturnDate()));

        try {
            loanTable.setItems(FXCollections.observableArrayList(loanDAO.listReturnedLoansWithDetails()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
