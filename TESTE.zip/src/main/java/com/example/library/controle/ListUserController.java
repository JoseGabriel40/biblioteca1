package com.example.library.controle;

import com.example.library.dao.LibraryUserDAO;
import com.example.library.model.LibraryUser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.SQLException;

public class ListUserController {

    @FXML private TableView<LibraryUser> userTable;
    @FXML private TableColumn<LibraryUser, Integer> idColumn;
    @FXML private TableColumn<LibraryUser, String> nameColumn;
    @FXML private TableColumn<LibraryUser, String> courseColumn;
    @FXML private TableColumn<LibraryUser, String> classColumn;
    @FXML private TextField searchField;

    private final ObservableList<LibraryUser> userData = FXCollections.observableArrayList();
    private final LibraryUserDAO userDAO;

    public ListUserController() throws SQLException {
        userDAO = new LibraryUserDAO();
    }

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(data -> data.getValue().idProperty().asObject());
        nameColumn.setCellValueFactory(data -> data.getValue().nameProperty());
        courseColumn.setCellValueFactory(data -> data.getValue().courseProperty());
        classColumn.setCellValueFactory(data -> data.getValue().turmaProperty());

        loadUsers();

        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterUsers(newVal));
    }

    private void loadUsers() {
        try {
            userData.setAll(userDAO.list());
            userTable.setItems(userData);
        } catch (SQLException e) {
            showError("Erro ao carregar usuários: " + e.getMessage());
        }
    }

    private void filterUsers(String filter) {
        if (filter == null || filter.isBlank()) {
            userTable.setItems(userData);
            return;
        }

        ObservableList<LibraryUser> filtered = FXCollections.observableArrayList();
        for (LibraryUser u : userData) {
            if (u.getName().toLowerCase().contains(filter.toLowerCase())
                    || u.getTurma().toLowerCase().contains(filter.toLowerCase())) {
                filtered.add(u);
            }
        }
        userTable.setItems(filtered);
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
