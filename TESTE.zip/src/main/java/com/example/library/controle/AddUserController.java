package com.example.library.controle;

import com.example.library.dao.LibraryUserDAO;
import com.example.library.model.LibraryUser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;

public class AddUserController {

    @FXML private TextField nameField, classField, searchField;
    @FXML private ComboBox<String> courseComboBox;
    @FXML private TableView<LibraryUser> userTable;
    @FXML private TableColumn<LibraryUser, String> nameColumn, courseColumn, classColumn;

    private final LibraryUserDAO userDAO = new LibraryUserDAO();
    private final ObservableList<LibraryUser> userList = FXCollections.observableArrayList();

    public AddUserController() throws SQLException {
    }

    @FXML
    public void initialize() {
        nameColumn.setCellValueFactory(data -> data.getValue().nameProperty());
        courseColumn.setCellValueFactory(data -> data.getValue().courseProperty());
        classColumn.setCellValueFactory(data -> data.getValue().turmaProperty());

        courseComboBox.setItems(FXCollections.observableArrayList("Informática", "Redes", "Edificações", "Eletrotécnica"));

        loadUsers();

        searchField.textProperty().addListener((obs, oldVal, newVal) -> filterUsers(newVal));
    }

    private void loadUsers() {
        try {
            userList.setAll(userDAO.list());
            userTable.setItems(userList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void filterUsers(String filter) {
        if (filter == null || filter.isEmpty()) {
            userTable.setItems(userList);
        } else {
            ObservableList<LibraryUser> filtered = FXCollections.observableArrayList();
            for (LibraryUser user : userList) {
                if (user.getName().toLowerCase().contains(filter.toLowerCase()) ||
                        user.getCourse().toLowerCase().contains(filter.toLowerCase()) ||
                        user.getTurma().toLowerCase().contains(filter.toLowerCase())) {
                    filtered.add(user);
                }
            }
            userTable.setItems(filtered);
        }
    }

    @FXML
    private void handleSave() {
        try {
            LibraryUser user = new LibraryUser();
            user.setName(nameField.getText());
            user.setCourse(courseComboBox.getValue());
            user.setTurma(classField.getText());

            userDAO.add(user);
            loadUsers();
            clearFields();
            showAlert("Sucesso", "Usuário cadastrado com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Erro", "Erro ao cadastrar usuário: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void clearFields() {
        nameField.clear();
        classField.clear();
        courseComboBox.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
