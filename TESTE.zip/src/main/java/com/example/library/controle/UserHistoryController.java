package com.example.library.controle;

import com.example.library.dao.LoanDAO;
import com.example.library.model.Loan;
import com.example.library.model.LibraryUser;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
import java.time.LocalDate;

public class UserHistoryController {

    @FXML private TableView<Loan> historyTable;
    @FXML private TableColumn<Loan, Integer> idColumn;
    @FXML private TableColumn<Loan, String> bookColumn;
    @FXML private TableColumn<Loan, LocalDate> loanDateColumn;
    @FXML private TableColumn<Loan, LocalDate> returnDateColumn;
    @FXML private TableColumn<Loan, String> statusColumn;

    private final LoanDAO loanDAO = new LoanDAO();

    public void loadHistory(LibraryUser user) {
        try {
            historyTable.setItems(FXCollections.observableArrayList(loanDAO.listUserHistory(user.getId())));
        } catch (SQLException e) {
            showAlert("Erro ao carregar histórico: " + e.getMessage());
        }
    }

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        bookColumn.setCellValueFactory(cellData -> cellData.getValue().getBook().titleProperty());
        loanDateColumn.setCellValueFactory(new PropertyValueFactory<>("loanDate"));
        returnDateColumn.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        statusColumn.setCellValueFactory(cellData -> {
            boolean returned = cellData.getValue().isReturned();
            return new ReadOnlyStringWrapper(returned ? "Devolvido" : "Em Aberto");
        });
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) historyTable.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
